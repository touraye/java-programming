package iphone;

public class Iphone4 extends Iphone3{

    //browser method
    @Override
    public void browser(){
        System.out.println("Iphone uses other browser");
    }

    //flashlight method
    public void flashLight(){
        System.out.println("Iphone have a flash light");
    }
}
