package iphone;

public class Iphone3 extends Iphone{
}
