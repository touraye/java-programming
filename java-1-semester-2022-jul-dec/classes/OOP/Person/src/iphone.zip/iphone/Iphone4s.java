package iphone;

public class Iphone4s extends Iphone4 {

    //google map method
    @Override
    public void googleMap(){
        System.out.println("Iphone uses iphone map");
    }
    //camera method
    @Override
    public void camera(){
        System.out.println("Iphone have camera");
    }

    //PotraitCamera method
    public void potraitCamera(){
        System.out.println("Iphone have a a potrait camera");
    }
}

