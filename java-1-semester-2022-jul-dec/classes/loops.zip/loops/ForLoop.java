public class ForLoop {
    public static void main(String[] args) {
//        System.out.println("Lets count up to ten!");
//        for(int i = 1; i < 10; i++){
//            if(i == 5) break;
//
//            System.out.println(i);
//
//        }
        boolean check = false;
        if(!check){
            System.out.println("yeah!");
        }
    }
}
